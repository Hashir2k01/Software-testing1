package com.mycompany.utils;

public class StringUtils {

    public String reverseString(String input) {
        return new StringBuilder(input).reverse().toString();
    }

    public boolean isEmpty(String str) {
        return str == null || str.isEmpty();
    }

    public String trim(String str) {
        return str == null ? null : str.trim();
    }

    public boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }
}
