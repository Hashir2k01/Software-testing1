package com.mycompany.utils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class StringUtilsTest {
    
    public StringUtilsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() throws Exception {
    }
    
    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() throws Exception {
    }
    
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testReverseString() {
        StringUtils stringUtils = new StringUtils();
        
        String result = stringUtils.reverseString("hello");
        assertEquals("olleh", result);
        
        result = stringUtils.reverseString("");
        assertEquals("", result);
        
        result = stringUtils.reverseString(null);
        assertNull(result);
    }

    @Test
    public void testIsEmpty() {
        StringUtils stringUtils = new StringUtils();
        
        
        assertFalse(stringUtils.isEmpty("hello"));
        
        
        assertTrue(stringUtils.isEmpty(""));
        
        
        assertTrue(stringUtils.isEmpty(null));
    }

    @Testp
    public void testTrim() {
        StringUtils stringUtils = new StringUtils();
        
        
        String result = stringUtils.trim("  hello  ");
        assertEquals("hello", result);
        
        
        result = stringUtils.trim("");
        assertEquals("", result);
        
        
        result = stringUtils.trim(null);
        assertNull(result);
    }

    @Test
    public void testIsNumeric() {
        StringUtils stringUtils = new StringUtils();
        
       
        assertTrue(stringUtils.isNumeric("123"));
        
        
        assertFalse(stringUtils.isNumeric("abc"));
        
        
        assertFalse(stringUtils.isNumeric(""));
        
        
        assertFalse(stringUtils.isNumeric(null));
    }
}
